BUKU KAS PEMBANGUNAN - ANDROID

Isi:
- Aplikasi Android native Kotlin.
- Database offline Room (SQLite) tersimpan permanen di penyimpanan aplikasi.
- Dashboard total pengeluaran dan jumlah transaksi.
- Tambah pengeluaran.
- Riwayat transaksi; transaksi dengan nama sama tetap terpisah.
- Widget layar utama untuk membuka input cepat.
- Tema biru.

CARA MEMBUAT APK:
1. Ekstrak ZIP di komputer.
2. Pasang Android Studio.
3. Buka folder BukuKasPembangunan melalui Android Studio.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK hasil build biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android dan instal.

CATATAN:
- Project ini adalah source project Android Studio, bukan APK siap instal.
- Widget ditambahkan dari daftar Widgets di layar utama Android setelah aplikasi terinstal:
  tekan lama layar utama > Widgets > Buku Kas Pembangunan.
- Ketuk widget untuk membuka form tambah pengeluaran.
- Database offline berada di penyimpanan privat aplikasi. Jangan uninstall aplikasi atau hapus data aplikasi jika ingin mempertahankan database.
- Versi awal ini dimulai dengan database kosong; catatan lama belum diimpor otomatis.
- Nominal input harus rupiah penuh, misalnya 450000 untuk Rp450.000.
