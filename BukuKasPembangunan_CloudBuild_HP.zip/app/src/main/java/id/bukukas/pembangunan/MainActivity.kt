package id.bukukas.pembangunan

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val dao by lazy { AppDatabase.get(this).expenseDao() }
    private lateinit var totalText: TextView
    private lateinit var countText: TextView
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        lifecycleScope.launch {
            dao.observeAll().collectLatest { rows -> render(rows) }
        }
        if (intent.action == ACTION_QUICK_ADD) showAddDialog()
    }

    private fun money(value: Long): String =
        NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value)
            .replace(",00", "")

    private fun buildScreen() {
        val blue = 0xFF1769AA.toInt()
        val darkBlue = 0xFF104B7A.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF3F7FB.toInt())
            setPadding(18, 22, 18, 12)
        }
        val header = TextView(this).apply {
            text = "BUKU KAS PEMBANGUNAN"
            textSize = 20f
            setTextColor(blue)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(header)
        totalText = TextView(this).apply {
            text = "TOTAL PENGELUARAN\nRp0"
            textSize = 22f
            setTextColor(-1)
            setPadding(18, 22, 18, 22)
            setBackgroundColor(darkBlue)
        }
        val totalParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 }
        root.addView(totalText, totalParams)
        countText = TextView(this).apply {
            text = "0 transaksi"
            textSize = 14f
            setTextColor(0xFF536779.toInt())
            setPadding(2, 12, 2, 12)
        }
        root.addView(countText)
        val add = Button(this).apply {
            text = "+ TAMBAH PENGELUARAN"
            setTextColor(-1)
            setBackgroundColor(blue)
            setOnClickListener { showAddDialog() }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, -2))
        val title = TextView(this).apply {
            text = "RIWAYAT PENGELUARAN"
            textSize = 16f
            setTextColor(darkBlue)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 20, 0, 10)
        }
        root.addView(title)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun render(rows: List<Expense>) {
        val total = rows.sumOf { it.amount }
        totalText.text = "TOTAL PENGELUARAN\n${money(total)}"
        countText.text = "${rows.size} transaksi"
        list.removeAllViews()
        rows.forEach { item ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(-1)
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = "${item.description}\n${item.date}"
                textSize = 15f
                setTextColor(0xFF20384B.toInt())
            }
            top.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val amount = TextView(this).apply {
                text = money(item.amount)
                textSize = 15f
                setTextColor(0xFF1769AA.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            top.addView(amount)
            line.addView(top)
            line.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Hapus transaksi?")
                    .setMessage("${item.description} — ${money(item.amount)}")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        lifecycleScope.launch { dao.delete(item) }
                    }.show()
                true
            }
            list.addView(line)
            val divider = View(this).apply {
                setBackgroundColor(0xFFDCE6EF.toInt())
            }
            list.addView(divider, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 8, 22, 0)
        }
        val date = EditText(this).apply {
            hint = "Tanggal, contoh 13/11"
            setText("${Calendar.getInstance().get(Calendar.DAY_OF_MONTH)}/${Calendar.getInstance().get(Calendar.MONTH) + 1}")
        }
        val description = EditText(this).apply { hint = "Keterangan, contoh Semen" }
        val amount = EditText(this).apply {
            hint = "Jumlah rupiah, contoh 450000"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(date)
        box.addView(description)
        box.addView(amount)
        AlertDialog.Builder(this)
            .setTitle("Tambah Pengeluaran")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val d = date.text.toString().trim()
                val desc = description.text.toString().trim()
                val value = amount.text.toString().toLongOrNull()
                if (d.isNotBlank() && desc.isNotBlank() && value != null && value > 0) {
                    lifecycleScope.launch {
                        dao.insert(Expense(date = d, description = desc, amount = value))
                        Toast.makeText(this@MainActivity, "Pengeluaran tersimpan", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Lengkapi tanggal, keterangan, dan jumlah.", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    companion object {
        const val ACTION_QUICK_ADD = "id.bukukas.pembangunan.QUICK_ADD"
    }
}
